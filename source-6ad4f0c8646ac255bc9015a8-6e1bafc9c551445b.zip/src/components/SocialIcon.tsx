import type { SocialLink } from '../data/types';

const paths: Record<SocialLink['icon'], string> = {
  linkedin:
    'M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0z',
  artstation:
    'M0 17.72l2.03 3.5A2.43 2.43 0 0 0 4.2 22.5h13.47l-2.79-4.78H0zm24 .02c0-.48-.14-.93-.39-1.31L15.7 2.69A2.42 2.42 0 0 0 13.56 1.5H9.4l12.15 21.05 1.92-3.32c.37-.63.53-1 .53-1.49zm-11.27-2.87L7.3 5.46 1.87 14.87h10.86z',
};

export default function SocialIcon({ icon }: { icon: SocialLink['icon'] }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d={paths[icon]} />
    </svg>
  );
}
